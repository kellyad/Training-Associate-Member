//
//  ViewController.h
//  training
//
//  Created by FS on 2/9/15.
//  Copyright (c) 2015 asdf. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController <UIAlertViewDelegate>

@property (atomic) int n;
@property (strong, nonatomic) NSString *string;
- (IBAction)btnLogin:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblTest;
@property (weak, nonatomic) IBOutlet UITextField *txtUsername;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
- (IBAction)dismissKeyboard:(id)sender;

//garbage collector
//pointer

//thread

//atomic -> thread safe
    //1 thread synchronized
//nonatomic ->  non-thread safe
    //cenderung lebih cepet

@end
