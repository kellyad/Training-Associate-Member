//
//  CustomerTableViewController.h
//  training
//
//  Created by prk on 2/9/15.
//  Copyright (c) 2015 asdf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Customer.h"
#import "DetailViewController.h"

@interface CustomerTableViewController : UITableViewController <NSURLConnectionDelegate>

//3 property yang wajib ada
@property (strong,nonatomic) NSURLConnection *connection;
@property (strong,nonatomic) NSMutableURLRequest *request;
@property (strong,nonatomic) NSMutableData *data;

@property (strong,nonatomic) NSMutableArray *arrayCustomer;

@property (nonatomic) int selectedIndex;

@end
